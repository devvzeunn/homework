var mysql			= require('mysql');
var dbconfig		= require('./config/database.js');
var connection		= mysql.createConnection(dbconfig);

/**
 * 데이터 초기화
 * @returns
 */
function initData() {
	var sql1 = "DROP TABLE PRODUCT;";
	var sql2 = "CREATE TABLE PRODUCT ("
			 + "		 PRD_CODE VARCHAR(100) NOT NULL"
			 + "		,SHOP_CODE VARCHAR(3) NOT NULL"
			 + "		,PRD_NM VARCHAR(400)"
			 + "		,PRD_PRICE VARCHAR(400)"
			 + "		,PRD_IMG_URL VARCHAR(400)"
			 + "		,PRD_DETAIL_URL VARCHAR(400)"
			 + ");";
	connection.query(sql1, null, function(err,result){
		connection.query(sql2, null, function(err,result){
		});
	});
}

/**
 * 상품목록 추가
 * @param prdList : 상품목록
 * @returns
 */
function addProductList(prdList) {
	for(var row in prdList){
		insertProductInfo(prdList[row].SHOP_CODE,prdList[row].PRD_CODE,prdList[row].PRD_NM,prdList[row].PRD_PRICE,prdList[row].PRD_IMG_URL,prdList[row].PRD_DETAIL_URL);
	}
}

/**
 * 
 * @param shopCode		: 쇼핑몰구분코드
 * @param prdCode		: 상품코드
 * @param prdNm			: 상품명
 * @param prdPrice		: 상품가격
 * @param prdImgUrl		: 상품이미지url
 * @param prdDetailUrl	: 상품상세url
 * @returns
 */
function insertProductInfo(shopCode, prdCode, prdNm, prdPrice, prdImgUrl, prdDetailUrl) {
	var sql2 = "INSERT INTO PRODUCT(SHOP_CODE,PRD_CODE,PRD_NM,PRD_PRICE,PRD_IMG_URL,PRD_DETAIL_URL) VALUES(?,?,?,?,?,?);";
		connection.query(sql2, [shopCode, prdCode, prdNm, prdPrice, prdImgUrl, prdDetailUrl],function(err,result){
			if(err) {
				console.log('에러 ::'+err);
			} else {
				console.log('insert success::'+shopCode+"::"+prdCode+"::"+prdNm+"::"+prdPrice+"::"+prdImgUrl+"::"+prdDetailUrl);
			}
		});
}

module.exports.initData = initData;
module.exports.addProductList = addProductList;