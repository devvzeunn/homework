var http				= require('http');
var express				= require('express');
var path				= require('path');
var serveStatic			= require('serve-static');
var bodyParser			= require('body-parser');
var crawlerModule		= require('./crawler-module');
var calculatorModule	= require('./time-calculator-module');
var inflectStrModule	= require('./inflect-str-module');

var app = express();
app.set('port', process.env.PORT || 3000);
app.use('/public', serveStatic(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.all('/testInflectStr', function(req, res) {
	var inputArr	= ["Product","SpecialGuest","Donald E. Knuth","Donald E.Knuth","_ specialGuest _"]; // 테스트 데이터
	var outputArr	= []; 
	
	for (var i = 0; i < inputArr.length; i++) {
		outputArr.push(inflectStrModule.inflectStr(inputArr[i]));
	}
	
	res.send(outputArr);
});


app.all('/testCalcTime', function(req, res) {
	var inputArr	= [{time:"PM:01:00:00", sec:"10"},{time:"PM:11:59:59", sec:"1"}, {time:"AM:12:10:00", sec:"40"},{time:"AM:05:24:03", sec:"102392"},{time:"AM:12:00:00", sec:"43200"}]; // 테스트 데이터
	var outputArr	= []; 
	
	for (var i = 0; i < inputArr.length; i++) {
		outputArr.push(calculatorModule.divideTimeArea(inputArr[i].time, inputArr[i].sec));
	}
	
	res.send(outputArr);
});

app.all('/inflectStr', function(req, res) {
	var targetStr = req.param('targetStr');
	
	res.send(inflectStrModule.inflectStr(targetStr));	
});

app.all('/calcTime', function(req, res) {
	var time = req.param('time');
	var sec = req.param('sec');
	
	res.send(calculatorModule.divideTimeArea(time, sec));
});

app.all('/crawling', function(request,response) {
	// 육육걸스 크롤링
	crawlerModule.crawlingProductInfo({
		 url		: 'http://www.66girls.co.kr/'
		,shopCode	: '001'
		,prdList	: 'ul.prdList > li'
		,type		: [{selector : '.thumbnail .prdImg a', attrType : 'pk-product_no', colNm : 'PRD_CODE'}
						,{selector : '.description strong.name a span:nth-child(2)', attrType : 'text', colNm : 'PRD_NM'}
						,{selector : '.description .spec li:nth-child(2) > span', attrType : 'text', colNm : 'PRD_PRICE'}
						,{selector : '.thumbnail a img', attrType : 'src', colNm : 'PRD_IMG_URL'}
						,{selector : '.thumbnail .prdImg a', attrType : 'href', colNm : 'PRD_DETAIL_URL'}]
	});
	
	// nining9 크롤링
	crawlerModule.crawlingProductInfo({
		 url		: 'http://www.naning9.com/'
		,shopCode	: '002'
		,prdList	: '.list_cell'
		,type		: [{selector : '> a', attrType : 'pk-index_no', colNm : 'PRD_CODE'}
						,{selector : 'li.item_name', attrType : 'text', colNm : 'PRD_NM'}
						,{selector : 'li.item_price > p', attrType : 'text', colNm : 'PRD_PRICE'}
						,{selector : '> a > img:nth-child(1)', attrType : 'src', colNm : 'PRD_IMG_URL'}
						,{selector : '> a', attrType : 'href', colNm : 'PRD_DETAIL_URL'}]
	});
	
	// 모코블링 크롤링
	crawlerModule.crawlingProductInfo({
		 url		: 'http://www.mocobling.com/'
		,shopCode	: '003'
		,prdList	: '.itembox'
		,type		: [{selector : '.cover_upper .img > a', attrType : 'pk-branduid', colNm : 'PRD_CODE'}
						,{selector : '.info .name > a', attrType : 'text', colNm : 'PRD_NM'}
						,{selector : '.info .prc span.prc_sell', attrType : 'text', colNm : 'PRD_PRICE'}
						,{selector : '.cover_upper .img > a > img', attrType : 'src', colNm : 'PRD_IMG_URL'}
						,{selector : '.cover_upper .img > a', attrType : 'href', colNm : 'PRD_DETAIL_URL'}]
	});
});

var server = http.createServer(app);
server.listen(app.get('port'), function() {
	console.log("SERVER START");
	require('./data-controller-module').initData();
});
