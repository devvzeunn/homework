$(function() {
	// 과제 1 > 크롤링 버튼 클릭 시 
	$('body').on('click', '#btnTestCrawling', Homework1.clickBtnCrwaling);

	// 과제 2 > 테스트 버튼 클릭 시 
	$('body').on('click', '#btnTestCalcTime', Homework2.clickTest);
	
	// 과제 2 > 계산하기 클릭 시 
	$('body').on('click', '#btnCalcTime', Homework2.clickBtnCalcTime);

	// 과제 3 > 테스트 버튼 클릭 시 
	$('body').on('click', '#btnTestInflectStr', Homework3.clickTest);
	
	// 과제 3 > 변환하기 버튼 클릭 시 
	$('body').on('click', '#btnInflectStr', Homework3.clickBtnInflectStr);
	
});

var Homework1 = {
	clickBtnCrwaling : function() {
		$.ajax({
			url:'/crawling',
			type:'POST',
			data:{
			},
			success:function(data){
				
			},
			error : function(xhr, status, error) {
				alert("에러가 발생하였습니다.");
			}
		});
	}
};

var Homework2 = {
	clickTest : function() {
		$.ajax({
			url:'/testCalcTime',
			type:'POST',
			data:{},
			success:function(result){
				for (var i = 0; i < result.length; i++) {
					$('#result'+(i+1)).text(result[i]);
				}
			},
			error : function(xhr, status, error) {
				alert("에러가 발생하였습니다.");
			}
		});
	},
	
	checkEmpty : function() {
		var flag = false;
		$req = $('.req');
		
		$req.each(function(index, item){
			var $item = $(item);
			
			if($req.is(':checked') == false){
			    alert($item.data('msg')+"선택해주세요");  
			    $item.focus();
			    flag = true;
			    return false;
			}
			
			if($item.val() == "" || $item == undefined) {
				alert($item.data('msg')+"을/를 입력해주세요.");
				$item.focus();
				flag = true;
				return false;
			}
		});
		
		return flag;
	},	
		
	clickBtnCalcTime : function() {
		var gubun = $('input[name="gubun"]:checked').val();
		var hh = $('input[name="hh"]').val();
		var mm = $('input[name="mm"]').val();
		var ss = $('input[name="ss"]').val();
		var sec = $('input[name="sec"]').val();

		// 유효성 검사
		if(Homework2.checkEmpty()) {
			return false;
		}
		
		// 유효성 검사
		if(parseInt(sec) > 200000) {
			alert("더할 시간(초)은 200000 이하의 자연수만 가능합니다.");
			$('input[name="sec"]').focus();
			return;
		}
		
		$.ajax({
			url:'/calcTime',
			type:'POST',
			data:{
				 time 	: gubun+":"+hh+":"+mm+":"+ss
				,sec 	: sec
			},
			success:function(result){
				$('#timeResult').text(result);
			},
			error : function(xhr, status, error) {
				alert("에러가 발생하였습니다.");
			}	
		});
	}
};

var Homework3 = {
	clickTest : function() {
		$.ajax({
			url:'/testInflectStr',
			type:'POST',
			data:{},
			success:function(result){
				for (var i = 0; i < result.length; i++) {
					$('#result'+(i+6)).text(result[i]);
				}
			},
			error : function(xhr, status, error) {
				alert("에러가 발생하였습니다.");
			}
		});
	},	
	
	clickBtnInflectStr : function() {
		var $targetStr = $('input[name="targetStr"]');
		
		if($targetStr.val() == '') {
			alert("문자열을 입력 후, 변환하기 버튼을 클릭하세요.");
			$targetStr.focus();
			return;
		}
		
		$.ajax({
			url:'/inflectStr',
			type:'POST',
			data:{targetStr : $targetStr.val()},
			success:function(result){
				$('#strResult').text(result);
			},
			error : function(xhr, status, error) {
				alert("에러가 발생하였습니다.");
			}	
		});
	}
};