module.exports = {
  host     : 'localhost',
  user     : 'root',
  password : '1234',
  port     : '3306',
  database : 'homework_db'
};