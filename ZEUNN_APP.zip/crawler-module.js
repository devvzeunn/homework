var client = require('cheerio-httpcli');
var dataControllerModule = require('./data-controller-module');

/**
 * 상품 크롤링
 * @param param.url			: 쇼핑몰 url
 * @param param.shopCode	: 쇼핑몰 구분코드
 * @param param.prdList		: 상품목록
 * @param param.type		: 상품정보 상세목록
 * @returns
 */
function crawlingProductInfo(param) {
	client.fetch(param.url, {}, function (err, $, res, html) {
		var $li			= $(param.prdList);
		var dataList	= new  Array();

		// 상품 목록 순회
		$li.each(function(){
			var data = new Object();
			for (var i = 0; i < param.type.length; i++) {
				var infoType	= param.type[i];
				var $item		= $(this).find(infoType.selector);
				
				if(infoType.attrType == 'text') {
					data[infoType.colNm] = $item.text().trim();
				} else if(infoType.attrType == 'val') {
					data[infoType.colNm] = $item.val().trim();
				} else if(infoType.attrType.includes('pk-')) {
					var detailUrl	= $item.attr('href'); // TODO > 예외처리필요
					var keyNm 		= infoType.attrType.replace('pk-', '');
					var regExp 		= new RegExp(keyNm+"=([^&]*)");
					data[infoType.colNm] = detailUrl.match(regExp)[1];
				} else if(infoType.attrType.includes('data-')) {
					data[infoType.colNm] = $item.data(infoType.attrType.replace('data-', ''));
				} else {
					data[infoType.colNm] = $item.attr(infoType.attrType);
				}
			}
			data.SHOP_CODE = param.shopCode;
			dataList.push(data);
		});
		dataControllerModule.addProductList(dataList);
	});
}

module.exports.crawlingProductInfo = crawlingProductInfo;
