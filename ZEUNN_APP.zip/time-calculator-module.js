var hh 		= 0;
var mm		= 0;
var ss		= 0;

/**
 * 시간 영역 분할 셋팅
 * @param time	: 문자열 형태의 변경 전 시간 ex) 14:00:00
 * @param sec	: 더할 시간(초 단위)
 * @returns
 */
function divideTimeArea(time, sec) {
	var timeArr = time.split(":");
	
	hh 	= (timeArr[0] == "PM") ? parseInt(timeArr[1]) + 12 : parseInt(timeArr[1]);
	mm 	= parseInt(timeArr[2]);
	ss 	= parseInt(timeArr[3]);
	
	// 자정에 대한 처리
	if(timeArr[1] == '12') {
		hh = (timeArr[0] == "PM") ? 12 : 0;
	}
	
	return calcTime(sec);
}

/**
 * 다음 단위 숫자로 변환
 * @param num	: 대상 숫자
 * @param unit	: 변환 시 단위
 * @returns
 */
function toNextUnitNum(num, unit) {
	return parseInt(num / unit);
}

/**
 * 시간 계산
 * @param sec : 더할 시간(초 단위)
 * @returns
 */
function calcTime(sec) {
	// 초 -> 단위 환산(시/분/초)
	var toHourVal		= parseInt((sec % (60*60*24)) / (60*60));
	var toMinuteVal		= parseInt((sec % (60*60)) / (60));
	var toSecondVal		= parseInt(sec % (60));
	
	// 초 셋팅  - 60초인 경우 0 처리
	var afterSec = ss + toSecondVal;
	afterSec = (afterSec < 60) ? afterSec : (afterSec - 60);
		
	// 분 셋팅 - 초에서 자리 수 넘어온 분을 더함
	var afterMin = (mm + toMinuteVal) + toNextUnitNum(ss + toSecondVal, 60);
	
	// 시간 셋팅 - 분에서 자리 수 넘어온 시간을 더함
	var afterHour = (hh + toHourVal) + toNextUnitNum(afterMin, 60); 
	
	// 60분인 경우 0처리
	afterHour = afterHour < 24 ? afterHour : afterHour - 24;
	afterMin = (afterMin < 60) ? afterMin : 0;
	
	return lpadTimeArea(afterHour)+":"+lpadTimeArea(afterMin)+":"+lpadTimeArea(afterSec);
}

/**
 * 시간 자리 수 셋팅 
 * @param num : 숫자
 * @returns
 */
function lpadTimeArea(num) {
	var size = 2;
	num = num + '';
	
	return num.length >= size ? num : new Array(size - num.length + 1).join('0') + num;
}

module.exports.divideTimeArea = divideTimeArea;