/**
 * 문자열 치환
 * @param str : 문자열
 * @returns
 */
function inflectStr(str) {
	return mkUnderbarEctChar(mkUnderbarCaps(str));
}

/**
 * 대문자 치환
 * @param str : 문자열
 * @returns
 */
function mkUnderbarCaps(str) {
	return str.replace(/([A-Z])/g, function(arg){
        return "_"+arg.toLowerCase();
    }).toLowerCase();
}

/**
 * 기타문자 치환
 * @param str : 문자열
 * @returns
 */
function mkUnderbarEctChar(str) {
	str = str.replace(/\s|\.|&|@|#|\*/g,'_'); // 공백 및 특수문자 치환
	str = str.replace(/(\s*)/g,''); // 공백 제거
	str = str.replace(/_*_/g,'_'); // 언더바 중복 제거
	str = str.replace(/^_|_$/g,''); // 문장 맨앞뒤 언더바 제거
	
	return str;
}

module.exports.inflectStr = inflectStr;